export class Tag {
    constructor(public _id: string, public name: string,public color: string) {}
}
  